<?php
/**
 * Emoji 表情
 *
 *
 * @author   fooleap <fooleap@gmail.com>
 * @version  2018-11-07 23:34:16
 * @link     https://github.com/fooleap/disqus-php-api
 *
 */
require_once('init.php');
print_r(jsonEncode($emoji -> eac()));
